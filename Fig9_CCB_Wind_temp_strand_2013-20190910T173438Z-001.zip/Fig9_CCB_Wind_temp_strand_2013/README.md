# run windstress_temperature_strandings_combine1.py to get the result
