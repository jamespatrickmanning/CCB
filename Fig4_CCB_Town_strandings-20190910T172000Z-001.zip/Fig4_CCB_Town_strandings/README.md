# run plt_turtle_city.py to get the fig.4.png
