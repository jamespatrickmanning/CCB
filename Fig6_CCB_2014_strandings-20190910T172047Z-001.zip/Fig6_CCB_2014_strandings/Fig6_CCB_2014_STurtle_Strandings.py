#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 23 11:33:33 2018
@author: huimin
Modified by Felicia July 2019 to function with Python3 and cleared unused commands/data
"""

import numpy as np
import matplotlib.pyplot as plt

fig,ax=plt.subplots(1,1,figsize=(10,6))#,sharex=True)
tt2014=np.load('tt2014.npy', encoding='bytes')
h2014=np.load('h2014.npy', encoding='bytes')

ax.bar(tt2014,h2014,width=0.5,label='retention')
ax.set_ylim([0,210])
plt.ylabel('Number', fontsize=13) 
plt.xlabel('Date', fontsize=13) 
ax.xaxis_font = {'size':'13'}
for label in ax.get_xticklabels():
        label.set_rotation(10)
plt.savefig('Fig6_CCB_2014_STurtle_Strandings',dpi=200,bbox_inches = "tight")
plt.savefig('Fig6_CCB_2014_STurtle_Strandings.eps',format='eps',dpi=400,bbox_inches = "tight")