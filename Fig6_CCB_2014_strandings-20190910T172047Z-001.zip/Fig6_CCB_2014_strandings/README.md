# CCB
This repository has a separate branch for each Figure in the Liu et al paper on simulating turtle strandings on Cape Cod.
This has the bar chart of 2014 strandings and data.
