# CCB
This repository has a separate branch for each Figure in the Liu et al paper on simulating turtle strandings on Cape Cod.
This branch has code for Figures 11, 12 and 13 where the latter two are related to backtracking particles. The full set is in the zip file. The "pltx.py" routine generates all three figures assuming other routines to conduct the particle tracking have already been run. The "other routines" are, for example, Back_forecast_function_2012.py and track2012.py.
