# CCB
JiM redid this figure in Jan 2019 to include the model and wind locations so the code is now "fig2_ccbay.py".
