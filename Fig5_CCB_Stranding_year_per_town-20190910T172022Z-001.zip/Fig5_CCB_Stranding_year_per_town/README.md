# CCB
This repository has a separate branch for each Figure in the Liu et al paper on simulating turtle strandings on Cape Cod.
This is the code for Figure 5 bar chart of strandings per town and year.
Note: JiM rewrote the code in June 2019 to clean it up.

