# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 14:47:56 2018

@author: xiaojian
Modified by Felicia June 2019 to remove unused commands/data and format for Python3
""" 

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# the following comes from Bob Prescott in Feb 2019
time=range(1979,2019)
num=[12,22,22,6,6,33,19,17,39,10,37,45,19,31,44,34,178,14,57,46,323,49,96,201,92,37,53,91,39,89,204,232,152,413,204,1241,613,476,420,818] # from Bob Prescott email in Feb 2019


fig,axes=plt.subplots(1,1,figsize=(8,4))

df=pd.Series(np.array(num).T,index=np.array(time).T)
df.plot(kind='bar',ax=axes,color='green')

axes.set_ylim([0,1400])
axes.set_title('Sea Turtle Strandings per Year',fontsize=13) #FMP
plt.ylabel('Number', fontsize=13) 
plt.xlabel('Year', fontsize=13) 
plt.savefig('Fig3_CCB_Annual_STurtle_Strandings.eps',format='eps',dpi=300,bbox_inches='tight')
plt.savefig('Fig3_CCB_Annual_STurtle_Strandings',dpi=300,bbox_inches='tight')