# CCB
This repository creates fig 3 in the Liu et al manuscript On simulating turtle strandings on Cape Cod with "strandings per year bar chart".
