# run windstress_temperature_strandings_combine.py to get the result 
