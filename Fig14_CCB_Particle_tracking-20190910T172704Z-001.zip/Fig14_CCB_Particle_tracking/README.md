# CCB
This repository has a separate branch for each Figure in the Liu et al paper on simulating turtle strandings on Cape Cod.
This branch has the file comparing GOM3 and MASSBAY particle tracking results. Since the input data is so large, it did not fit on github but is available on request in a file called "CCB_fig14-master.zip".
