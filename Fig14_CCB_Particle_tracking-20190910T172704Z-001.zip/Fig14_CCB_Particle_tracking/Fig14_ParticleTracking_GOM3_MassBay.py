# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 09:48:58 2018
@author: huimin
Modified by JiM in Feb 2019
Modified by Felicia July 2019 to function with Python 3 and removed unused commands
"""
import numpy as np
import matplotlib.pyplot as plt

date='Nov_18_25_2014'
filepath=''
m26=np.load('m_psFVCOM20141118_7days.npy', encoding='bytes', allow_pickle=True)#FMP encoded and pickle for Python3 
p=m26.tolist()
FN='necscoast_worldvec.dat'
CL=np.genfromtxt(FN,names=['lon','lat'])
fig=plt.figure(figsize=(17,7))
plt.subplots_adjust(wspace=0.08,hspace=0.1)
############ Draw GOM3 ###########
ax1=fig.add_subplot(1,2,1)  
ax1.plot(CL['lon'],CL['lat'],'b-')

for a in np.arange(len(p[b'lon'][0])):
    ax1.scatter(p[b'lon'][0][a][0],p[b'lat'][0][a][0],color='green')
    if len(p[b'lon'][0][a])>=361:
        
        ax1.scatter(p[b'lon'][0][a][360],p[b'lat'][0][a][360],color='red')
        ax1.plot([p[b'lon'][0][a][0],p[b'lon'][0][a][360]],[p[b'lat'][0][a][0],p[b'lat'][0][a][360]],'y-')#,linewidth=0.5)
    else:
        ax1.scatter(p[b'lon'][0][a][-1],p[b'lat'][0][a][-1],color='red')
        ax1.plot(p[b'lon'][0][a][0:],p[b'lat'][0][a][0:],'y-')

ax1.scatter(p[b'lon'][0][a][0],p[b'lat'][0][a][0],label='Start',color='green')
ax1.scatter(p[b'lon'][0][a][-1],p[b'lat'][0][a][-1],label='End',color='red') 
ax1.legend(loc='upper right',scatterpoints=1) 
ax1.set_xlim([-70.7,-69.9])
ax1.set_ylim([41.5,42.1]) 
ax1.set_title('GOM3',fontsize=16)
for tick in ax1.xaxis.get_major_ticks():  
    tick.label1.set_fontsize(13) 
for tick in ax1.yaxis.get_major_ticks():  
    tick.label1.set_fontsize(13) 
##################draw massbay##################
ax2=fig.add_subplot(1,2,2)
ax2.plot(CL['lon'],CL['lat'],'b-')
    
lons=np.load(filepath+'lonmassbay.npy', encoding='bytes')
lats=np.load(filepath+'latmassbay.npy', encoding='bytes')
times=np.load(filepath+'timemassbay.npy', encoding='bytes')

for i in range(len(lons)):
    ax2.scatter(lons[i][0],lats[i][0],color='green')
    ax2.scatter(lons[i][-2],lats[i][-2],color='red')
    ax2.plot(lons[i][:],lats[i][:],'y-')

ax2.scatter(lons[i][0],lats[i][0],label='Start',color='green')
ax2.scatter(lons[i][-2],lats[i][-2],label='End',color='red')   
ax2.legend(loc='upper right',scatterpoints=1) 
ax2.set_xlim([-70.7,-69.9])
ax2.set_ylim([41.5,42.1])
ax2.set_yticklabels([])
ax2.set_title('MassBay',fontsize=16)
for tick in ax2.xaxis.get_major_ticks():  
    tick.label1.set_fontsize(13) 
    
plt.savefig('Fig14_CCB_ParticleTracks_GOM3_MassBay.eps',format='eps',dpi=400,bbox_inches='tight')
plt.savefig('Fig14_CCB_ParticleTracks_GOM3_MassBay',dpi=400,bbox_inches='tight')
plt.show()